﻿Add-Type -AssemblyName System.Windows.Forms

$script:filePath = $null
$rootFolder = "C:\Users"
$script:toggle = 0

$form = New-Object System.Windows.Forms.Form
$form.Text = "Fire Jason Virtual Camera"
$form.Size = New-Object System.Drawing.Size(380, 300)
$form.StartPosition = "CenterScreen"

$panel = New-Object System.Windows.Forms.FlowLayoutPanel
$panel.Dock = "Fill"
$panel.FlowDirection = "TopDown"
$panel.WrapContents = $false
$panel.AutoScroll = $true
$panel.Padding = '10,10,10,10'
$form.Controls.Add($panel)

# Labels
$label1 = New-Object System.Windows.Forms.Label
$label1.Text = "Fire Jason Virtual Camera by westaxibitonas0"
$label1.Font = New-Object System.Drawing.Font("Arial",10,[System.Drawing.FontStyle]::Bold)
$label1.AutoSize = $true
$panel.Controls.Add($label1)

$label2 = New-Object System.Windows.Forms.Label
$label2.Text = "Please refer to documentation before proceeding."
$label2.Font = New-Object System.Drawing.Font("Arial",9)
$label2.AutoSize = $true
$panel.Controls.Add($label2)

# Helper function to add buttons
function Add-Button($text, $action) {
    $btn = New-Object System.Windows.Forms.Button
    $btn.Text = $text
    $btn.Size = New-Object System.Drawing.Size(240,30)
    $btn.Add_Click($action)
    $panel.Controls.Add($btn)
    return $btn
}

# Driver / Dependencies button
Add-Button "Set up / Remove Drivers" {
    try {
        $firstBat  = Get-ChildItem $rootFolder -Filter "Install.bat" -Recurse | Select-Object -First 1
        $secondBat = Get-ChildItem $rootFolder -Filter "Uninstall.bat" -Recurse | Select-Object -First 1
        if (-not $firstBat -or -not $secondBat) { [System.Windows.Forms.MessageBox]::Show("Could not find driver .bat files."); return }

        # Check Python & pip
        $pythonInstalled = $false
        try { cmd /c "py --version" >$null 2>&1; if ($LASTEXITCODE -eq 0) { $pythonInstalled=$true } } catch {}
        if (-not $pythonInstalled) { [System.Windows.Forms.MessageBox]::Show("Python not installed. Install Python first."); return }

        $pipInstalled = $false
        try { cmd /c "py -m pip --version" >$null 2>&1; if ($LASTEXITCODE -eq 0) { $pipInstalled=$true } } catch {}
        if (-not $pipInstalled) { Start-Process "py" -ArgumentList "-m ensurepip --default-pip" -Wait }

        # Install dependencies
        $deps = @("opencv-python","pyvirtualcam")
        foreach ($pkg in $deps) { Start-Process "py" -ArgumentList "-m pip install $pkg --upgrade" -WindowStyle Hidden -Wait }

        # Install / uninstall drivers
        if ($script:toggle -eq 0) { Start-Process $firstBat.FullName -Wait; $script:toggle=1; [System.Windows.Forms.MessageBox]::Show("Drivers installed + dependencies ready.") }
        else { Start-Process $secondBat.FullName -Wait; $script:toggle=0; [System.Windows.Forms.MessageBox]::Show("Drivers removed.") }

    } catch { [System.Windows.Forms.MessageBox]::Show("Driver setup error: $($_.Exception.Message)") }
}

# Select video file
Add-Button "Select Video File" {
    $FileBrowser = New-Object System.Windows.Forms.OpenFileDialog
    $FileBrowser.InitialDirectory = "C:\"
    $FileBrowser.Filter = "Video files (*.mp4)|*.mp4|All Files (*.*)|*.*"
    if ($FileBrowser.ShowDialog() -eq "OK") { $script:filePath = $FileBrowser.FileName; [System.Windows.Forms.MessageBox]::Show("Selected video:`n$($script:filePath)") }
}

# Run virtual camera
Add-Button "Run Virtual Camera" {
    if (-not $script:filePath) { [System.Windows.Forms.MessageBox]::Show("No video file selected."); return }
    $exePath = Get-ChildItem $rootFolder -Filter "FireJ1.exe" -Recurse | Select-Object -First 1
    if (-not $exePath) { [System.Windows.Forms.MessageBox]::Show("FireJ1.exe not found."); return }

    Start-Process -FilePath $exePath.FullName -ArgumentList "`"$($script:filePath)`"" | Out-Null
    [System.Windows.Forms.MessageBox]::Show("Virtual camera started.")
}

# Stop virtual camera
Add-Button "Stop Virtual Camera" {
    $procName = "FireJ1"  # EXE name without .exe
    $procs = Get-Process -Name $procName -ErrorAction SilentlyContinue
    if ($procs) { $procs | Stop-Process -Force; [System.Windows.Forms.MessageBox]::Show("Virtual camera stopped.") }
    else { [System.Windows.Forms.MessageBox]::Show("Camera is not running.") }
}

$form.ShowDialog()

import sys
import cv2
import pyvirtualcam
import os
import subprocess
import tkinter as tk
from tkinter import filedialog, messagebox
import threading
import argparse
import atexit

# ===============================
# GLOBAL STATE
# ===============================
drivers_installed = False
uninstall_ran = False

camera_stop_event = threading.Event()
camera_thread = None


# ===============================
# DRIVER UNINSTALL
# ===============================
def run_uninstall_bat():
    global uninstall_ran, drivers_installed

    if uninstall_ran or not drivers_installed:
        return

    uninstall_ran = True

    try:
        for root, dirs, files in os.walk("C:\\Users"):
            if "Uninstall.bat" in files:
                bat_path = os.path.join(root, "Uninstall.bat")
                subprocess.run(bat_path, shell=True)
                print("Uninstall.bat executed.")
                return
        print("Uninstall.bat not found.")
    except Exception as e:
        print(f"Uninstall failed: {e}")


atexit.register(run_uninstall_bat)


# ===============================
# CAMERA FUNCTION
# ===============================
def run_virtual_camera(video_path):
    try:
        cap = cv2.VideoCapture(video_path)
        if not cap.isOpened():
            raise RuntimeError("Failed to open video file")

        width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        fps = cap.get(cv2.CAP_PROP_FPS) or 30

        with pyvirtualcam.Camera(width=width, height=height, fps=fps) as cam:
            print("Virtual camera started")
            while not camera_stop_event.is_set():
                ret, frame = cap.read()
                if not ret:
                    cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
                    continue

                frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                cam.send(frame)
                cam.sleep_until_next_frame()

        cap.release()
        print("Virtual camera stopped cleanly")

    except Exception as e:
        print(f"Camera error: {e}")
        return 1

    return 0


# ===============================
# GUI APP
# ===============================
class FireJasonVirtualCamera:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("Fire Jason Virtual Camera")
        self.root.geometry("380x400")
        self.root.resizable(False, False)

        self.root.eval('tk::PlaceWindow %s center' % self.root.winfo_toplevel())

        self.file_path = None
        self.root_folder = "C:\\Users"
        self.toggle = 0

        self.create_widgets()
        self.root.protocol("WM_DELETE_WINDOW", self.on_closing)

    def create_widgets(self):
        frame = tk.Frame(self.root)
        frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        self.status_label = tk.Label(frame, text="Status: Ready", fg="green")
        self.status_label.pack(pady=5)

        tk.Button(frame, text="Set up / Remove Drivers", width=30, command=self.setup_drivers).pack(pady=5)
        tk.Button(frame, text="Select Video File", width=30, command=self.select_video_file).pack(pady=5)
        tk.Button(frame, text="Run Virtual Camera", width=30, command=self.start_camera).pack(pady=5)
        tk.Button(frame, text="Stop Virtual Camera", width=30, command=self.stop_camera).pack(pady=5)

        self.file_label = tk.Label(frame, text="No video selected", fg="gray", wraplength=350)
        self.file_label.pack(pady=10)

    def find_file(self, filename):
        for root, dirs, files in os.walk(self.root_folder):
            if filename in files:
                return os.path.join(root, filename)
        return None

    # -------------------------------
    # DRIVERS
    # -------------------------------
    def setup_drivers(self):
        threading.Thread(target=self._setup_drivers_thread, daemon=True).start()

    def _setup_drivers_thread(self):
        global drivers_installed

        install_bat = self.find_file("Install.bat")
        uninstall_bat = self.find_file("Uninstall.bat")

        if not install_bat or not uninstall_bat:
            messagebox.showerror("Error", "Driver .bat files not found")
            return

        try:
            if self.toggle == 0:
                subprocess.run(install_bat, shell=True, check=True)
                drivers_installed = True
                self.toggle = 1
                self.status_label.config(text="Status: Drivers installed", fg="green")
                messagebox.showinfo("Success", "Drivers installed")
            else:
                subprocess.run(uninstall_bat, shell=True, check=True)
                drivers_installed = False
                self.toggle = 0
                self.status_label.config(text="Status: Drivers removed", fg="green")
                messagebox.showinfo("Success", "Drivers removed")
        except Exception as e:
            messagebox.showerror("Error", str(e))
            self.status_label.config(text="Status: Error", fg="red")

    # -------------------------------
    # VIDEO
    # -------------------------------
    def select_video_file(self):
        path = filedialog.askopenfilename(
            title="Select Video File",
            filetypes=[("Video files", "*.mp4;*.avi;*.mov;*.mkv")]
        )
        if path:
            self.file_path = path
            self.file_label.config(text=f"Selected: {os.path.basename(path)}", fg="blue")

    # -------------------------------
    # CAMERA CONTROL
    # -------------------------------
    def start_camera(self):
        global camera_thread

        if not self.file_path:
            messagebox.showerror("Error", "No video selected")
            return

        if camera_thread and camera_thread.is_alive():
            messagebox.showinfo("Info", "Camera already running")
            return

        camera_stop_event.clear()

        camera_thread = threading.Thread(
            target=run_virtual_camera,
            args=(self.file_path,),
            daemon=True
        )
        camera_thread.start()

        self.status_label.config(text="Status: Camera running", fg="green")

    def stop_camera(self):
        if camera_thread and camera_thread.is_alive():
            camera_stop_event.set()
            self.status_label.config(text="Status: Camera stopped", fg="green")
        else:
            messagebox.showinfo("Info", "Camera is not running")

    # -------------------------------
    # EXIT
    # -------------------------------
    def on_closing(self):
        if messagebox.askokcancel("Quit", "Do you want to quit?"):
            camera_stop_event.set()
            run_uninstall_bat()
            self.root.destroy()

    def run(self):
        self.root.mainloop()


# ===============================
# MAIN
# ===============================
def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("video_file", nargs="?")
    args = parser.parse_args()

    if args.video_file:
        return run_virtual_camera(args.video_file)
    else:
        app = FireJasonVirtualCamera()
        app.run()
        return 0


if __name__ == "__main__":
    sys.exit(main())

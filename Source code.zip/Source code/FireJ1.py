import sys
import cv2
import pyvirtualcam

try:
    if len(sys.argv) < 2:
        raise ValueError("No video file provided.")

    video_path = sys.argv[1]
    cap = cv2.VideoCapture(video_path)

    if not cap.isOpened():
        raise IOError("Cannot open video file")

    width  = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    fps    = cap.get(cv2.CAP_PROP_FPS) or 30

    with pyvirtualcam.Camera(width=width, height=height, fps=fps, print_fps=True) as cam:
        print(f'Virtual camera started: {cam.device}')
        while True:
            ret, frame = cap.read()
            if not ret:
                cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
                continue

            frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            cam.send(frame)
            cam.sleep_until_next_frame()

except Exception as e:
    print("PYTHON ERROR:", e)
    sys.exit(1)

